/* MissionChief Dispatchers Alliance Portal — Front-end SPA */
(function () {
  const STORAGE = {
    rulesAccepted: "mcd_rules_accepted",
    buildingRequests: "mcd_building_requests",
    trainingRequests: "mcd_training_requests",
    adminKey: "mcd_admin_unlocked"
  };

  const pages = {
    home: renderHome,
    rules: renderRules,
    request: renderBuildingRequest,
    training: renderTrainingRequest,
    maps: renderMaps,
    admin: renderAdmin
  };

  // ---------- Helpers ----------
  function $(sel, root = document) { return root.querySelector(sel); }
  function $$(sel, root = document) { return [...root.querySelectorAll(sel)]; }
  function load(key, fallback = []) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; }
    catch { return fallback; }
  }
  function save(key, data) { localStorage.setItem(key, JSON.stringify(data)); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ---------- Navigation ----------
  function setActive(page) {
    $$(".side-nav button").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.page === page);
    });
  }

  function navigate(page) {
    if (!pages[page]) page = "home";
    location.hash = page;
    setActive(page);
    const app = $("#app");
    app.innerHTML = "";
    pages[page](app);
    // close mobile menu
    $("#sideMenu")?.classList.remove("open");
  }

  // ---------- HOME ----------
  function renderHome(root) {
    root.innerHTML = `
      <section class="hero">
        <div class="eyebrow">MISSIONCHIEF DISPATCHERS ALLIANCE</div>
        <h1>Coordinate.<br><span>Respond.</span><br>Protect.</h1>
        <p class="lead">
          Official alliance portal for MissionChief dispatchers across the UK, US and Australia.
          Shared rules, verification, infrastructure requests, training coordination and live maps —
          all in one place.
        </p>
      </section>

      <section class="section">
        <div class="card feature-photo">
          <img src="DQD1f.jpg" alt="MissionChief Dispatchers control room — 911, 999 and 000 emergency services">
          <p class="photo-caption">Alliance Dispatch Control Room — multi-region operations online</p>
        </div>
      </section>

      <section class="section">
        <h2>Emergency <span>Services</span></h2>
        <p class="lead" style="margin-bottom:24px">
          The four pillars of our alliance response network. Every department works under the same
          verification and coordination standards.
        </p>
        <div class="dept-grid">
          <article class="dept-card">
            <img src="police.jpg" alt="Police response unit">
            <div class="dept-body">
              <h3>Police</h3>
              <p>Law enforcement coordination, incident command support and multi-agency response across US, UK and AU servers.</p>
            </div>
          </article>
          <article class="dept-card">
            <img src="fire.jpg" alt="Firefighters at emergency scene">
            <div class="dept-body">
              <h3>Fire</h3>
              <p>Structure fires, vehicle incidents, hazmat and mutual-aid firefighting operations managed through shared dispatch channels.</p>
            </div>
          </article>
          <article class="dept-card">
            <img src="ems.jpg" alt="Ambulance and EMS crew">
            <div class="dept-body">
              <h3>EMS</h3>
              <p>Emergency medical services, rapid response units and hospital hand-off coordination for all alliance regions.</p>
            </div>
          </article>
          <article class="dept-card">
            <img src="coastal.jpg" alt="Coastal rescue boat on the water">
            <div class="dept-body">
              <h3>Coastal Rescue</h3>
              <p>Maritime search &amp; rescue, coastal patrol and water-based incident support for UK and Australian waters.</p>
            </div>
          </article>
        </div>
      </section>

      <section class="section">
        <h2>Alliance <span>Status</span></h2>
        <div class="grid">
          <div class="card">
            <div class="stat">3 <small>Active Regions</small></div>
            <p>UK • US • AU servers linked under one alliance protocol.</p>
          </div>
          <div class="card">
            <div class="stat">24/7 <small>Dispatch Coverage</small></div>
            <p>Round-the-clock coordination between verified alliance members.</p>
          </div>
          <div class="card">
            <div class="stat">Shared <small>Infrastructure</small></div>
            <p>Building requests, training and maps available to every verified dispatcher.</p>
          </div>
        </div>
      </section>
    `;
  }

  // ---------- RULES & VERIFICATION ----------
  function renderRules(root) {
    const accepted = load(STORAGE.rulesAccepted, []);
    root.innerHTML = `
      <section class="section">
        <h2>Rules &amp; <span>Verification</span></h2>
        <p class="lead">Read and accept the alliance rules before requesting verification. All members are held to the same standard across UK, US and AU.</p>
      </section>

      <div class="rules">
        <div class="rule">
          <h2>1. Conduct &amp; Respect</h2>
          <p>Treat every dispatcher, player and admin with professionalism. Toxicity, harassment, discrimination or trolling results in immediate removal from the alliance.</p>
        </div>
        <div class="rule">
          <h2>2. Role-play Standards</h2>
          <p>Stay in character while on duty. Use realistic radio procedure, call signs and response language. Metagaming and powergaming are not permitted.</p>
        </div>
        <div class="rule">
          <h2>3. Multi-Region Protocol</h2>
          <p>Alliance channels serve UK, US and AU. Identify your server clearly on every request. Do not cross-post operational traffic that confuses other regions.</p>
        </div>
        <div class="rule">
          <h2>4. Building &amp; Training Requests</h2>
          <p>All shared infrastructure and training requests must go through this portal. Do not spam Discord for approvals. False or duplicate requests will be rejected.</p>
        </div>
        <div class="rule">
          <h2>5. Verification</h2>
          <p>You must be an active MissionChief player on one of the supported servers. Provide accurate username, server and Discord tag. Fake accounts are banned permanently.</p>
        </div>
      </div>

      <section class="section">
        <h2>Accept Rules &amp; <span>Request Verification</span></h2>
        <form class="form" id="verifyForm">
          <div class="field">
            <label>MissionChief Username</label>
            <input name="username" required placeholder="Your in-game name" maxlength="40">
          </div>
          <div class="field">
            <label>Server</label>
            <div class="choices" id="serverChoices">
              <div class="choice server-us" data-value="US">US</div>
              <div class="choice server-uk" data-value="UK">UK</div>
              <div class="choice server-au" data-value="AU">AU</div>
            </div>
            <input type="hidden" name="server" required>
          </div>
          <div class="field">
            <label>Discord Tag</label>
            <input name="discord" required placeholder="username#0000 or @username" maxlength="40">
          </div>
          <div class="field">
            <label class="check">
              <input type="checkbox" name="accept" required>
              <span>I have read and accept the MissionChief Dispatchers Alliance rules.</span>
            </label>
          </div>
          <button type="submit" class="btn primary">Submit Verification Request</button>
          <div id="verifyMsg" class="notice" style="display:none;margin-top:16px"></div>
        </form>
      </section>

      ${accepted.length ? `
      <section class="section">
        <h2>Recent <span>Acceptances</span></h2>
        <table class="table">
          <thead><tr><th>Username</th><th>Server</th><th>Discord</th><th>Date</th></tr></thead>
          <tbody>
            ${accepted.slice().reverse().slice(0, 10).map(r => `
              <tr>
                <td>${escapeHtml(r.username)}</td>
                <td><span class="pill">${escapeHtml(r.server)}</span></td>
                <td>${escapeHtml(r.discord)}</td>
                <td>${new Date(r.ts).toLocaleDateString()}</td>
              </tr>`).join("")}
          </tbody>
        </table>
      </section>` : ""}
    `;

    // choice buttons
    $$("#serverChoices .choice").forEach(c => {
      c.addEventListener("click", () => {
        $$("#serverChoices .choice").forEach(x => x.classList.remove("active"));
        c.classList.add("active");
        $("input[name=server]").value = c.dataset.value;
      });
    });

    $("#verifyForm").addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      if (!fd.get("server")) {
        showMsg("verifyMsg", "Please select a server.", true);
        return;
      }
      const record = {
        id: uid(),
        username: fd.get("username").trim(),
        server: fd.get("server"),
        discord: fd.get("discord").trim(),
        ts: Date.now()
      };
      const list = load(STORAGE.rulesAccepted, []);
      list.push(record);
      save(STORAGE.rulesAccepted, list);
      showMsg("verifyMsg", "Verification request recorded. An admin will review it shortly.", false);
      e.target.reset();
      $$("#serverChoices .choice").forEach(x => x.classList.remove("active"));
      setTimeout(() => navigate("rules"), 1200);
    });
  }

  function showMsg(id, text, isError) {
    const el = document.getElementById(id);
    if (!el) return;
    el.style.display = "block";
    el.className = "notice " + (isError ? "danger" : "success");
    el.textContent = text;
  }

  // ---------- BUILDING REQUEST ----------
  function renderBuildingRequest(root) {
    root.innerHTML = `
      <section class="section">
        <h2>Building <span>Request</span></h2>
        <p class="lead">Request shared infrastructure (stations, posts, helipads, etc.) for alliance use. Provide clear location and justification.</p>
      </section>
      <form class="form" id="buildingForm">
        <div class="field">
          <label>Your Username</label>
          <input name="username" required maxlength="40">
        </div>
        <div class="field">
          <label>Server</label>
          <div class="choices" id="bServerChoices">
            <div class="choice server-us" data-value="US">US</div>
            <div class="choice server-uk" data-value="UK">UK</div>
            <div class="choice server-au" data-value="AU">AU</div>
          </div>
          <input type="hidden" name="server" required>
        </div>
        <div class="field">
          <label>Building Type</label>
          <input name="type" required placeholder="e.g. Fire Station, Police Post, Ambulance Station, Coastal Rescue Base" maxlength="60">
        </div>
        <div class="field">
          <label>Location / Coordinates</label>
          <input name="location" required placeholder="City, street or map coordinates" maxlength="80">
        </div>
        <div class="field">
          <label>Justification</label>
          <textarea name="reason" required placeholder="Why is this building needed for alliance operations?"></textarea>
        </div>
        <button type="submit" class="btn primary">Submit Building Request</button>
        <div id="buildingMsg" class="notice" style="display:none;margin-top:16px"></div>
      </form>
    `;

    $$("#bServerChoices .choice").forEach(c => {
      c.addEventListener("click", () => {
        $$("#bServerChoices .choice").forEach(x => x.classList.remove("active"));
        c.classList.add("active");
        $("input[name=server]").value = c.dataset.value;
      });
    });

    $("#buildingForm").addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      if (!fd.get("server")) {
        showMsg("buildingMsg", "Please select a server.", true);
        return;
      }
      const list = load(STORAGE.buildingRequests, []);
      list.push({
        id: uid(),
        username: fd.get("username").trim(),
        server: fd.get("server"),
        type: fd.get("type").trim(),
        location: fd.get("location").trim(),
        reason: fd.get("reason").trim(),
        status: "pending",
        ts: Date.now()
      });
      save(STORAGE.buildingRequests, list);
      showMsg("buildingMsg", "Building request submitted successfully.", false);
      e.target.reset();
      $$("#bServerChoices .choice").forEach(x => x.classList.remove("active"));
    });
  }

  // ---------- TRAINING REQUEST ----------
  function renderTrainingRequest(root) {
    root.innerHTML = `
      <section class="section">
        <h2>Training <span>Request</span></h2>
        <p class="lead">Request formal training sessions or certifications for yourself or your unit. Select category and preferred server.</p>
      </section>
      <form class="form" id="trainingForm">
        <div class="field">
          <label>Your Username</label>
          <input name="username" required maxlength="40">
        </div>
        <div class="field">
          <label>Server</label>
          <div class="choices" id="tServerChoices">
            <div class="choice server-us" data-value="US">US</div>
            <div class="choice server-uk" data-value="UK">UK</div>
            <div class="choice server-au" data-value="AU">AU</div>
          </div>
          <input type="hidden" name="server" required>
        </div>
        <div class="field">
          <label>Training Category</label>
          <div class="choices" id="trainCats">
            <div class="choice train-choice" data-value="Dispatch Basics" style="--train-color:#3b8eff">Dispatch Basics</div>
            <div class="choice train-choice" data-value="Multi-Agency" style="--train-color:#a855f7">Multi-Agency</div>
            <div class="choice train-choice" data-value="Coastal / Marine" style="--train-color:#22d3ee">Coastal / Marine</div>
            <div class="choice train-choice" data-value="Advanced Command" style="--train-color:#ef4444">Advanced Command</div>
          </div>
          <input type="hidden" name="category" required>
        </div>
        <div class="field">
          <label>Additional Notes</label>
          <textarea name="notes" placeholder="Preferred times, unit size, specific focus..."></textarea>
        </div>
        <button type="submit" class="btn primary">Submit Training Request</button>
        <div id="trainingMsg" class="notice" style="display:none;margin-top:16px"></div>
      </form>
    `;

    $$("#tServerChoices .choice").forEach(c => {
      c.addEventListener("click", () => {
        $$("#tServerChoices .choice").forEach(x => x.classList.remove("active"));
        c.classList.add("active");
        $("input[name=server]").value = c.dataset.value;
      });
    });
    $$("#trainCats .choice").forEach(c => {
      c.addEventListener("click", () => {
        $$("#trainCats .choice").forEach(x => x.classList.remove("active"));
        c.classList.add("active");
        $("input[name=category]").value = c.dataset.value;
      });
    });

    $("#trainingForm").addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      if (!fd.get("server") || !fd.get("category")) {
        showMsg("trainingMsg", "Please select server and training category.", true);
        return;
      }
      const list = load(STORAGE.trainingRequests, []);
      list.push({
        id: uid(),
        username: fd.get("username").trim(),
        server: fd.get("server"),
        category: fd.get("category"),
        notes: fd.get("notes").trim(),
        status: "pending",
        ts: Date.now()
      });
      save(STORAGE.trainingRequests, list);
      showMsg("trainingMsg", "Training request submitted.", false);
      e.target.reset();
      $$("#tServerChoices .choice, #trainCats .choice").forEach(x => x.classList.remove("active"));
    });
  }

  // ---------- MAPS ----------
  function renderMaps(root) {
    root.innerHTML = `
      <section class="section">
        <h2>Alliance <span>Maps</span></h2>
        <p class="lead">Shared Google Map of alliance stations, posts and points of interest across all regions.</p>
      </section>
      <div class="card" style="text-align:center;padding:48px 24px">
        <h3 style="margin-top:0">Open Alliance Map</h3>
        <p style="color:var(--muted);max-width:520px;margin:0 auto 24px">
          The live collaborative map is hosted on Google Maps. Use it to locate partner stations,
          plan mutual aid and mark new infrastructure requests.
        </p>
        <a class="btn primary" href="https://www.google.com/maps" target="_blank" rel="noopener">
          Open Google Maps
        </a>
        <p style="margin-top:28px;font-size:13px;color:#64748b">
          Replace the link above with your actual shared alliance map URL when ready.
        </p>
      </div>
    `;
  }

  // ---------- ADMIN ----------
  function renderAdmin(root) {
    const unlocked = localStorage.getItem(STORAGE.adminKey) === "1";
    if (!unlocked) {
      root.innerHTML = `
        <section class="section">
          <h2>Admin <span>Control Room</span></h2>
          <form class="form" id="adminLogin" style="max-width:400px">
            <div class="field">
              <label>Admin Passcode</label>
              <input type="password" name="code" required placeholder="Enter passcode" autocomplete="off">
            </div>
            <button type="submit" class="btn primary">Unlock</button>
            <div id="adminMsg" class="notice" style="display:none;margin-top:16px"></div>
          </form>
        </section>
      `;
      $("#adminLogin").addEventListener("submit", e => {
        e.preventDefault();
        // simple local passcode — change for production
        if (e.target.code.value === "mcd-admin") {
          localStorage.setItem(STORAGE.adminKey, "1");
          navigate("admin");
        } else {
          showMsg("adminMsg", "Incorrect passcode.", true);
        }
      });
      return;
    }

    const accepted = load(STORAGE.rulesAccepted, []);
    const buildings = load(STORAGE.buildingRequests, []);
    const trainings = load(STORAGE.trainingRequests, []);

    root.innerHTML = `
      <section class="section">
        <h2>Admin <span>Control Room</span></h2>
        <p class="lead">Local records only (browser storage). Connect a backend for true multi-user operation.</p>
        <button class="btn danger" id="adminLock" style="margin-bottom:20px">Lock Admin</button>
      </section>

      <div class="admin-grid" style="margin-bottom:40px">
        <div class="card"><div class="stat">${accepted.length}<small>Verifications</small></div></div>
        <div class="card"><div class="stat">${buildings.length}<small>Building Requests</small></div></div>
        <div class="card"><div class="stat">${trainings.length}<small>Training Requests</small></div></div>
      </div>

      <section class="section">
        <h2>Verification <span>Queue</span></h2>
        ${tableOrEmpty(accepted, ["Username", "Server", "Discord", "Date"], r => `
          <tr>
            <td>${escapeHtml(r.username)}</td>
            <td><span class="pill">${escapeHtml(r.server)}</span></td>
            <td>${escapeHtml(r.discord)}</td>
            <td>${new Date(r.ts).toLocaleString()}</td>
          </tr>`)}
      </section>

      <section class="section">
        <h2>Building <span>Requests</span></h2>
        ${tableOrEmpty(buildings, ["User", "Server", "Type", "Location", "Status", "Date"], r => `
          <tr>
            <td>${escapeHtml(r.username)}</td>
            <td><span class="pill">${escapeHtml(r.server)}</span></td>
            <td>${escapeHtml(r.type)}</td>
            <td>${escapeHtml(r.location)}</td>
            <td>${escapeHtml(r.status)}</td>
            <td>${new Date(r.ts).toLocaleDateString()}</td>
          </tr>`)}
      </section>

      <section class="section">
        <h2>Training <span>Requests</span></h2>
        ${tableOrEmpty(trainings, ["User", "Server", "Category", "Status", "Date"], r => `
          <tr>
            <td>${escapeHtml(r.username)}</td>
            <td><span class="pill">${escapeHtml(r.server)}</span></td>
            <td>${escapeHtml(r.category)}</td>
            <td>${escapeHtml(r.status)}</td>
            <td>${new Date(r.ts).toLocaleDateString()}</td>
          </tr>`)}
      </section>
    `;

    $("#adminLock").addEventListener("click", () => {
      localStorage.removeItem(STORAGE.adminKey);
      navigate("admin");
    });
  }

  function tableOrEmpty(rows, headers, rowFn) {
    if (!rows.length) return `<p style="color:var(--muted)">No records yet.</p>`;
    return `
      <table class="table">
        <thead><tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr></thead>
        <tbody>${rows.slice().reverse().map(rowFn).join("")}</tbody>
      </table>`;
  }

  // ---------- Boot ----------
  function init() {
    // side menu
    $$(".side-nav button").forEach(btn => {
      btn.addEventListener("click", () => navigate(btn.dataset.page));
    });
    $("#menuToggle")?.addEventListener("click", () => {
      $("#sideMenu").classList.toggle("open");
    });

    window.addEventListener("hashchange", () => {
      const page = location.hash.replace("#", "") || "home";
      navigate(page);
    });

    const start = location.hash.replace("#", "") || "home";
    navigate(start);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
