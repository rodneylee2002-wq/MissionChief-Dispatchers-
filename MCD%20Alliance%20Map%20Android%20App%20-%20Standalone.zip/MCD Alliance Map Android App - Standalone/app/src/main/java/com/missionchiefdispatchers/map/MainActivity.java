package com.missionchiefdispatchers.map;

import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

public class MainActivity extends AppCompatActivity {
    private static final String SITE = "https://mission-chief-dispatchers.onhercules.app/";
    private static final int BG = Color.rgb(2,7,13);
    private static final int CARD = Color.rgb(7,17,29);
    private static final int BLUE = Color.rgb(0,140,255);
    private static final int RED = Color.rgb(255,24,48);
    private static final int TEXT = Color.rgb(235,242,249);
    private static final int MUTED = Color.rgb(145,165,184);

    private FrameLayout content;
    private LinearLayout nav;
    private WebView web;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle state) {
        SplashScreen.installSplashScreen(this);
        super.onCreate(state);
        showHome();
    }

    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans", Typeface.BOLD));
        t.setLetterSpacing(.08f);
        return t;
    }

    private GradientDrawable bg(int color, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Button action(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(bg(color, 0, 5));
        return b;
    }

    private void base(String title, String subtitle) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(18), dp(14), dp(18), dp(12));
        TextView logo = label("MCD", 22, BLUE);
        header.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(48)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(label("MISSIONCHIEF", 15, BLUE));
        brand.addView(label("DISPATCHERS", 9, TEXT));
        header.addView(brand);
        root.addView(header);

        View divider = new View(this);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{BLUE, RED});
        divider.setBackground(gd);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(2)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(dp(5), dp(5), dp(5), dp(7));
        nav.setBackground(bg(CARD, Color.rgb(20,45,65), 0));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(70)));
        setContentView(root);
    }

    private void addNav(String text, int index, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(TEXT); b.setTextSize(10); b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(click);
        nav.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void navBar() {
        addNav("⌂\nHOME", 0, v -> showHome());
        addNav("◉\nMAP", 1, v -> showMap());
        addNav("▤\nRULES", 2, v -> showRules());
        addNav("◎\nREGIONS", 3, v -> showRegions());
    }

    private void showHome() {
        base("HOME", "");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(28), dp(18), dp(24));
        TextView eyebrow = label("REGIONAL NETWORK · MCD", 11, BLUE);
        box.addView(eyebrow);
        TextView h = label("ALLIANCE\nBUILDING MAP", 31, TEXT);
        h.setPadding(0, dp(10), 0, dp(8)); box.addView(h);
        TextView p = new TextView(this);
        p.setText("MissionChief Dispatchers\nUS · UK · AU");
        p.setTextSize(16); p.setTextColor(MUTED); box.addView(p);
        Space sp = new Space(this); box.addView(sp, new LinearLayout.LayoutParams(1, dp(25)));
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(bg(CARD, Color.rgb(12,45,70), 6));
        card.addView(label("LIVE ALLIANCE NETWORK", 12, BLUE));
        TextView ct = new TextView(this);
        ct.setText("View synchronized alliance buildings across all three MissionChief regions.");
        ct.setTextColor(TEXT); ct.setTextSize(15); ct.setPadding(0, dp(10), 0, dp(14));
        card.addView(ct);
        Button open = action("OPEN ALLIANCE MAP  →", BLUE); open.setOnClickListener(v -> showMap());
        card.addView(open);
        box.addView(card);
        Space sp2 = new Space(this); box.addView(sp2, new LinearLayout.LayoutParams(1, dp(20)));
        TextView status = new TextView(this);
        status.setText("AUTOMATIC SYNC\nThe live map connects to the MCD web service for US, UK and AU alliance building data.");
        status.setTextColor(MUTED); status.setTextSize(13); box.addView(status);
        scroll.addView(box); content.addView(scroll);
        navBar();
    }

    private void showMap() {
        base("MAP", "");
        web = new WebView(this); web.setBackgroundColor(BG);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient());
        web.loadUrl(SITE);
        content.addView(web, new FrameLayout.LayoutParams(-1,-1));
        navBar();
    }

    private void showRules() {
        base("RULES", "");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(28), dp(18), dp(24));
        box.addView(label("MCD · GOVERNANCE", 11, BLUE));
        TextView h = label("ALLIANCE RULES", 30, TEXT); h.setPadding(0,dp(10),0,dp(15)); box.addView(h);
        String[] rules = {
            "ARTICLE 1 — GENERAL RULES",
            "Rules apply to all members of the MissionChief Dispatchers alliance.",
            "Members agree to abide by the rules and any changes made by leadership.",
            "ARTICLE 2 — CONDUCT & RESPECT",
            "Maintain professionalism and courtesy in alliance communications.",
            "Discrimination, harassment, or disruptive behavior is prohibited.",
            "Uphold integrity and realism in gameplay.",
            "Missions involving terrorism, school shootings, attacks against government or first responders, or similar content are not allowed."
        };
        for (String r: rules) {
            TextView t = new TextView(this); t.setText(r);
            t.setTextSize(r.startsWith("ARTICLE") ? 12 : 14);
            t.setTextColor(r.startsWith("ARTICLE") ? BLUE : TEXT);
            t.setTypeface(Typeface.create("sans", r.startsWith("ARTICLE") ? Typeface.BOLD : Typeface.NORMAL));
            t.setPadding(0, dp(7), 0, dp(7)); box.addView(t);
        }
        scroll.addView(box); content.addView(scroll); navBar();
    }

    private void showRegions() {
        base("REGIONS", "");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(28), dp(18), dp(18));
        box.addView(label("REGIONAL NETWORK", 11, BLUE));
        TextView h = label("MISSIONCHIEF SERVERS", 28, TEXT); h.setPadding(0,dp(10),0,dp(18)); box.addView(h);
        addRegion(box, "🇺🇸", "UNITED STATES", "US", "MissionChief US");
        addRegion(box, "🇬🇧", "UNITED KINGDOM", "UK", "MissionChief UK");
        addRegion(box, "🇦🇺", "AUSTRALIA", "AU", "MissionChief AU");
        ScrollView scroll = new ScrollView(this); scroll.addView(box); content.addView(scroll); navBar();
    }

    private void addRegion(LinearLayout box, String flag, String name, String code, String desc) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(15),dp(16),dp(15)); card.setBackground(bg(CARD, Color.rgb(12,45,70), 6));
        TextView top = new TextView(this); top.setText(flag+"   "+name+"   "+code);
        top.setTextColor(TEXT); top.setTextSize(15); top.setTypeface(Typeface.DEFAULT_BOLD); card.addView(top);
        TextView d = new TextView(this); d.setText(desc+"\nAlliance building data is available through the live map.");
        d.setTextColor(MUTED); d.setTextSize(13); d.setPadding(0,dp(8),0,dp(10)); card.addView(d);
        Button b = action("OPEN WORLD  →", BLUE); b.setOnClickListener(v -> showMap()); card.addView(b);
        box.addView(card, new LinearLayout.LayoutParams(-1, dp(150)));
        Space s = new Space(this); box.addView(s, new LinearLayout.LayoutParams(1,dp(12)));
    }

    @Override public void onBackPressed() {
        if (web != null && web.getVisibility() == View.VISIBLE && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }
}
