# MCD Alliance Map — Standalone Android App v2

This version is designed to feel like a real Android app rather than a bare website wrapper.

## Native app experience
- MCD-branded Android splash screen using Android's SplashScreen API.
- Native MCD header and bottom navigation.
- Native Home screen.
- Native Rules screen.
- Native US / UK / AU Regions screen.
- Live Alliance Map screen loads the existing MCD map/service.
- Android back navigation is handled.
- Dark navy + electric blue + red MCD visual system.

The Android SplashScreen API is used for Android 12+ and compatibility through AndroidX, following Android's current guidance.

## Build
Upload this project to GitHub. The included GitHub Actions workflow builds a debug APK automatically.

## Security
MissionChief cookies/credentials are NOT bundled in the app. They remain server-side on the existing MCD map backend.
